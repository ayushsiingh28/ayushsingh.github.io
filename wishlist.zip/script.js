// Simple cart and wishlist logic
const cart = [];
const wishlist = [];

const cartCount = document.getElementById('cart-count');
const wishlistCount = document.getElementById('wishlist-count');
const cartItems = document.getElementById('cart-items');
const wishlistItems = document.getElementById('wishlist-items');
const cartEmpty = document.getElementById('cart-empty');
const wishlistEmpty = document.getElementById('wishlist-empty');

function updateCart() {
    if (!cartCount || !cartItems || !cartEmpty) return;
    cartCount.textContent = cart.length;
    cartItems.innerHTML = '';
    if (cart.length === 0) {
        cartEmpty.style.display = 'block';
    } else {
        cartEmpty.style.display = 'none';
        cart.forEach(item => {
            const li = document.createElement('li');
            li.textContent = item;
            cartItems.appendChild(li);
        });
    }
}

function updateWishlist() {
    if (!wishlistCount || !wishlistItems || !wishlistEmpty) return;
    wishlistCount.textContent = wishlist.length;
    wishlistItems.innerHTML = '';
    if (wishlist.length === 0) {
        wishlistEmpty.style.display = 'block';
    } else {
        wishlistEmpty.style.display = 'none';
        wishlist.forEach(item => {
            const li = document.createElement('li');
            li.textContent = item;
            wishlistItems.appendChild(li);
        });
    }
}

document.querySelectorAll('.product').forEach(product => {
    const name = product.querySelector('h3').textContent;
    const addCartBtn = product.querySelector('.add-cart');
    const addWishlistBtn = product.querySelector('.add-wishlist');
    if (addCartBtn) {
        addCartBtn.addEventListener('click', () => {
            cart.push(name);
            updateCart();
        });
    }
    if (addWishlistBtn) {
        addWishlistBtn.addEventListener('click', () => {
            wishlist.push(name);
            updateWishlist();
        });
    }
    const buyNowBtn = product.querySelector('.buy-now');
    if (buyNowBtn) {
        buyNowBtn.addEventListener('click', () => {
            alert('Buy Now clicked for ' + name + '. Payment integration coming soon!');
        });
    }
});

updateCart();
updateWishlist();

// --- Simple Register/Login Logic ---
function showLogin() {
    document.getElementById('login-form').style.display = 'block';
    document.getElementById('register-form').style.display = 'none';
}
function showRegister() {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'block';
}
if (document.getElementById('show-login') && document.getElementById('show-register')) {
    document.getElementById('show-login').onclick = showLogin;
    document.getElementById('show-register').onclick = showRegister;
}

// Store users in localStorage (for demo only)
function getUsers() {
    return JSON.parse(localStorage.getItem('users') || '{}');
}
function setUsers(users) {
    localStorage.setItem('users', JSON.stringify(users));
}

// Register
const registerForm = document.getElementById('register-form');
if (registerForm) {
registerForm.onsubmit = function(e) {
    e.preventDefault();
    const name = document.getElementById('register-name').value.trim();
    const username = document.getElementById('register-username').value.trim();
    const email = document.getElementById('register-email').value.trim();
    const phone = document.getElementById('register-phone').value.trim();
    const address = document.getElementById('register-address').value.trim();
    const password = document.getElementById('register-password').value;
    const confirm = document.getElementById('register-confirm').value;
    const error = document.getElementById('register-error');
    error.style.display = 'none';
    if (password !== confirm) {
        error.textContent = 'Passwords do not match.';
        error.style.display = 'block';
        return;
    }
    let users = getUsers();
    // Check for unique email and username
    for (let userEmail in users) {
        if (users[userEmail].username === username) {
            error.textContent = 'Username already taken.';
            error.style.display = 'block';
            return;
        }
    }
    if (users[email]) {
        error.textContent = 'Email already registered.';
        error.style.display = 'block';
        return;
    }
    users[email] = { name, username, phone, address, password };
    setUsers(users);
    alert('Registration successful! You can now log in.');
    // Clear register form fields
    registerForm.reset();
    showLogin();
};
}

// Login
const loginForm = document.getElementById('login-form');
if (loginForm) {
loginForm.onsubmit = function(e) {
    e.preventDefault();
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    const error = document.getElementById('login-error');
    error.style.display = 'none';
    let users = getUsers();
    if (!users[email] || users[email].password !== password) {
        error.textContent = 'Invalid email or password.';
        error.style.display = 'block';
        return;
    }
    // Show username instead of email
    const username = users[email].username;
    document.getElementById('user-name').textContent = `Hello, ${username}`;
    document.getElementById('user-info').style.display = 'inline-block';
    document.getElementById('main-content').style.display = 'block';
    document.getElementById('auth-section').querySelector('#login-form').style.display = 'none';
    document.getElementById('auth-section').querySelector('#register-form').style.display = 'none';
    document.getElementById('auth-tabs').style.display = 'none';
    // Clear login form fields
    loginForm.reset();
};
}

// Sign out
const signoutBtn = document.getElementById('signout-btn');
if (signoutBtn) {
    signoutBtn.addEventListener('click', function() {
        document.getElementById('user-info').style.display = 'none';
        document.getElementById('main-content').style.display = 'none';
        document.getElementById('auth-section').querySelector('#login-form').style.display = 'block';
        document.getElementById('auth-tabs').style.display = 'block';
    });
}

// Hide main content if not logged in
if (!userLoggedIn) {
    document.getElementById('main-content').style.display = 'none';
} 